Please complete all sections.

### Configuration

- Provider Gem: `omniauth-*`
- Ruby Version: ``
- Framework: ``
- Platform: ``

### Expected Behavior

Tell us what should happen.

### Actual Behavior

Tell us what happens instead.

### Steps to Reproduce

Please list all steps to reproduce the issue.
