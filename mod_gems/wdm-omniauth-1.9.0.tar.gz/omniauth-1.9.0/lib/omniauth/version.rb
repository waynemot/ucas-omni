module OmniAuth
  VERSION = '1.9.0'.freeze
end
