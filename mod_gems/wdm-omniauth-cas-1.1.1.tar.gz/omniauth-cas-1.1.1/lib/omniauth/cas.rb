require 'omniauth/cas/version'
require 'omniauth/strategies/cas'