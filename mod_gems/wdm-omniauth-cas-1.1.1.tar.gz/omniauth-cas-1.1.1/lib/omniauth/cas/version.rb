module Omniauth
  module Cas
    VERSION = '1.1.1'
  end
end
